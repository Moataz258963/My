export interface ChatMessage {
  id: string
  senderId: string
  senderName: string
  receiverId: string
  content: string
  timestamp: string
  isRead: boolean
}

export interface ChatUser {
  id: string
  username: string
  fullName: string
  profilePicture?: string
  isOnline: boolean
  lastOnline: string
}

export interface ApiResponse {
  message?: string
  error?: string
  data?: any
  messages?: ChatMessage[]
  users?: ChatUser[]
}

export async function sendMessage(receiverId: string, content: string): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/messages/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ receiverId, content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Failed to send message" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function getMessages(chatId: string): Promise<ApiResponse> {
  try {
    const response = await fetch(`/api/messages/${chatId}`)
    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Failed to load messages" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function getOnlineUsers(): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/users/online")
    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Failed to load users" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export function getChatId(userId1: string, userId2: string): string {
  return [userId1, userId2].sort().join("_")
}

export function formatTime(timestamp: string, isArabic = false): string {
  return new Date(timestamp).toLocaleTimeString(isArabic ? "ar" : "en", {
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function formatLastSeen(timestamp: string, isArabic = false): string {
  const date = new Date(timestamp)
  const now = new Date()
  const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
  const diffInHours = Math.floor(diffInMinutes / 60)

  if (diffInMinutes < 5) {
    return isArabic ? "متصل" : "Online"
  } else if (diffInHours < 1) {
    return isArabic ? `منذ ${diffInMinutes} دقيقة` : `${diffInMinutes}m ago`
  } else if (diffInHours < 24) {
    return isArabic ? `منذ ${diffInHours} ساعة` : `${diffInHours}h ago`
  } else {
    return isArabic ? `آخر ظهور ${date.toLocaleDateString("ar")}` : `Last seen ${date.toLocaleDateString("en")}`
  }
}

export interface RegisterFormData {
  username: string
  email: string
  fullName: string
  password: string
  profilePicture?: File
}

export interface LoginFormData {
  username: string
  password: string
}

export interface User {
  id: string
  username: string
  email: string
  fullName: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

export interface ApiResponse {
  message?: string
  error?: string
  user?: User
}

export async function registerUser(formData: RegisterFormData): Promise<ApiResponse> {
  const form = new FormData()
  form.append("username", formData.username)
  form.append("email", formData.email)
  form.append("fullName", formData.fullName)
  form.append("password", formData.password)

  if (formData.profilePicture) {
    form.append("profilePicture", formData.profilePicture)
  }

  try {
    const response = await fetch("/api/auth/register", {
      method: "POST",
      body: form,
    })

    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Registration failed" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function loginUser(formData: LoginFormData): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })

    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Login failed" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function logoutUser(): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/auth/logout", {
      method: "POST",
    })

    const data = await response.json()
    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function getCurrentUser(): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/auth/me")
    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Not authenticated" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export function validateForm(formData: RegisterFormData): string | null {
  if (!formData.username.trim()) {
    return "Username is required"
  }

  if (formData.username.length < 3) {
    return "Username must be at least 3 characters long"
  }

  if (!formData.email.trim()) {
    return "Email is required"
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(formData.email)) {
    return "Please enter a valid email address"
  }

  if (!formData.fullName.trim()) {
    return "Full name is required"
  }

  if (!formData.password) {
    return "Password is required"
  }

  if (formData.password.length < 6) {
    return "Password must be at least 6 characters long"
  }

  return null
}

export function validateLoginForm(formData: LoginFormData): string | null {
  if (!formData.username.trim()) {
    return "Username is required"
  }

  if (!formData.password) {
    return "Password is required"
  }

  return null
}

export interface UpdateProfileData {
  fullName: string
  email: string
  currentPassword?: string
  newPassword?: string
}

export interface ApiResponse {
  message?: string
  error?: string
  user?: any
}

export async function updateProfile(profileData: UpdateProfileData): Promise<ApiResponse> {
  try {
    const response = await fetch("/api/profile/update", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(profileData),
    })

    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Profile update failed" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export async function uploadProfilePicture(file: File): Promise<ApiResponse> {
  try {
    const formData = new FormData()
    formData.append("profilePicture", file)

    const response = await fetch("/api/profile/upload-picture", {
      method: "POST",
      body: formData,
    })

    const data = await response.json()

    if (!response.ok) {
      return { error: data.error || "Profile picture upload failed" }
    }

    return data
  } catch (error) {
    return { error: "Network error. Please try again." }
  }
}

export function validateProfileForm(profileData: UpdateProfileData): string | null {
  if (!profileData.fullName.trim()) {
    return "Full name is required"
  }

  if (!profileData.email.trim()) {
    return "Email is required"
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(profileData.email)) {
    return "Please enter a valid email address"
  }

  if (profileData.newPassword) {
    if (!profileData.currentPassword) {
      return "Current password is required to change password"
    }

    if (profileData.newPassword.length < 6) {
      return "New password must be at least 6 characters long"
    }
  }

  return null
}

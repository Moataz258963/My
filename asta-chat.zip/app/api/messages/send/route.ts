import { type NextRequest, NextResponse } from "next/server"
import { jwtVerify } from "jose"
import { writeFile, readFile, mkdir } from "fs/promises"
import { existsSync } from "fs"
import path from "path"

interface Message {
  id: string
  senderId: string
  senderName: string
  receiverId: string
  content: string
  timestamp: string
  isRead: boolean
}

interface ChatRoom {
  id: string
  participants: string[]
  messages: Message[]
  lastActivity: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const CHATS_FILE = path.join(DATA_DIR, "chats.json")

async function ensureDataDirectory() {
  if (!existsSync(DATA_DIR)) {
    await mkdir(DATA_DIR, { recursive: true })
  }
}

async function getChats(): Promise<ChatRoom[]> {
  try {
    if (!existsSync(CHATS_FILE)) {
      return []
    }
    const data = await readFile(CHATS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function saveChats(chats: ChatRoom[]) {
  await ensureDataDirectory()
  await writeFile(CHATS_FILE, JSON.stringify(chats, null, 2))
}

function getChatRoomId(userId1: string, userId2: string): string {
  return [userId1, userId2].sort().join("_")
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")
    const { payload } = await jwtVerify(token, secret)
    const senderId = payload.userId as string
    const senderUsername = payload.username as string

    const { receiverId, content } = await request.json()

    if (!receiverId || !content?.trim()) {
      return NextResponse.json({ error: "Receiver ID and content are required" }, { status: 400 })
    }

    const chats = await getChats()
    const chatRoomId = getChatRoomId(senderId, receiverId)

    let chatRoom = chats.find((chat) => chat.id === chatRoomId)

    if (!chatRoom) {
      chatRoom = {
        id: chatRoomId,
        participants: [senderId, receiverId],
        messages: [],
        lastActivity: new Date().toISOString(),
      }
      chats.push(chatRoom)
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId,
      senderName: senderUsername,
      receiverId,
      content: content.trim(),
      timestamp: new Date().toISOString(),
      isRead: false,
    }

    chatRoom.messages.push(newMessage)
    chatRoom.lastActivity = new Date().toISOString()

    await saveChats(chats)

    return NextResponse.json({
      message: "Message sent successfully",
      data: newMessage,
    })
  } catch (error) {
    console.error("Send message error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

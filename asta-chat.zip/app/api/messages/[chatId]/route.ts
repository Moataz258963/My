import { type NextRequest, NextResponse } from "next/server"
import { jwtVerify } from "jose"
import { readFile, writeFile } from "fs/promises"
import { existsSync } from "fs"
import path from "path"

interface Message {
  id: string
  senderId: string
  senderName: string
  receiverId: string
  content: string
  timestamp: string
  isRead: boolean
}

interface ChatRoom {
  id: string
  participants: string[]
  messages: Message[]
  lastActivity: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const CHATS_FILE = path.join(DATA_DIR, "chats.json")

async function getChats(): Promise<ChatRoom[]> {
  try {
    if (!existsSync(CHATS_FILE)) {
      return []
    }
    const data = await readFile(CHATS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function saveChats(chats: ChatRoom[]) {
  await writeFile(CHATS_FILE, JSON.stringify(chats, null, 2))
}

export async function GET(request: NextRequest, { params }: { params: { chatId: string } }) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")
    const { payload } = await jwtVerify(token, secret)
    const userId = payload.userId as string

    const chats = await getChats()
    const chatRoom = chats.find((chat) => chat.id === params.chatId)

    if (!chatRoom) {
      return NextResponse.json({ messages: [] })
    }

    // Check if user is participant in this chat
    if (!chatRoom.participants.includes(userId)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Mark messages as read for the current user
    let hasUnreadMessages = false
    chatRoom.messages.forEach((message) => {
      if (message.receiverId === userId && !message.isRead) {
        message.isRead = true
        hasUnreadMessages = true
      }
    })

    if (hasUnreadMessages) {
      await saveChats(chats)
    }

    return NextResponse.json({ messages: chatRoom.messages })
  } catch (error) {
    console.error("Get messages error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

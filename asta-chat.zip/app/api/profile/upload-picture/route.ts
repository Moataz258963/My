import { type NextRequest, NextResponse } from "next/server"
import { jwtVerify } from "jose"
import { writeFile, readFile, mkdir, unlink } from "fs/promises"
import { existsSync } from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  fullName: string
  passwordHash: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads")

async function ensureDirectories() {
  if (!existsSync(UPLOADS_DIR)) {
    await mkdir(UPLOADS_DIR, { recursive: true })
  }
}

async function getUsers(): Promise<User[]> {
  try {
    if (!existsSync(USERS_FILE)) {
      return []
    }
    const data = await readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function saveUsers(users: User[]) {
  await writeFile(USERS_FILE, JSON.stringify(users, null, 2))
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")
    const { payload } = await jwtVerify(token, secret)
    const userId = payload.userId as string

    const formData = await request.formData()
    const profilePicture = formData.get("profilePicture") as File | null

    if (!profilePicture || profilePicture.size === 0) {
      return NextResponse.json({ error: "Profile picture is required" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(profilePicture.type)) {
      return NextResponse.json({ error: "Invalid file type. Please upload an image." }, { status: 400 })
    }

    // Validate file size (5MB max)
    const maxSize = 5 * 1024 * 1024 // 5MB
    if (profilePicture.size > maxSize) {
      return NextResponse.json({ error: "File too large. Maximum size is 5MB." }, { status: 400 })
    }

    const users = await getUsers()
    const userIndex = users.findIndex((user) => user.id === userId)

    if (userIndex === -1) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const user = users[userIndex]

    await ensureDirectories()

    // Delete old profile picture if it exists
    if (user.profilePicture) {
      const oldPicturePath = path.join(process.cwd(), "public", user.profilePicture)
      try {
        if (existsSync(oldPicturePath)) {
          await unlink(oldPicturePath)
        }
      } catch (error) {
        console.error("Error deleting old profile picture:", error)
      }
    }

    // Save new profile picture
    const bytes = await profilePicture.arrayBuffer()
    const buffer = Buffer.from(bytes)

    const fileExtension = profilePicture.name.split(".").pop()
    const fileName = `${user.username}_${Date.now()}.${fileExtension}`
    const filePath = path.join(UPLOADS_DIR, fileName)

    await writeFile(filePath, buffer)

    // Update user profile picture path
    user.profilePicture = `/uploads/${fileName}`
    user.lastOnline = new Date().toISOString()

    users[userIndex] = user
    await saveUsers(users)

    // Return updated user (without password hash)
    const { passwordHash, ...userResponse } = user
    return NextResponse.json({
      message: "Profile picture updated successfully",
      user: userResponse,
    })
  } catch (error) {
    console.error("Profile picture upload error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { readFile } from "fs/promises"
import { existsSync } from "fs"
import path from "path"
import bcrypt from "bcryptjs"
import { SignJWT } from "jose"

interface User {
  id: string
  username: string
  email: string
  fullName: string
  passwordHash: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")

async function getUsers(): Promise<User[]> {
  try {
    if (!existsSync(USERS_FILE)) {
      return []
    }
    const data = await readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function updateUserLastOnline(username: string) {
  try {
    const users = await getUsers()
    const userIndex = users.findIndex((user) => user.username === username)

    if (userIndex !== -1) {
      users[userIndex].lastOnline = new Date().toISOString()
      await require("fs/promises").writeFile(USERS_FILE, JSON.stringify(users, null, 2))
    }
  } catch (error) {
    console.error("Error updating last online:", error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    if (!username || !password) {
      return NextResponse.json({ error: "Username and password are required" }, { status: 400 })
    }

    const users = await getUsers()
    const user = users.find((u) => u.username === username)

    if (!user) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    const isValidPassword = await bcrypt.compare(password, user.passwordHash)

    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Update last online time
    await updateUserLastOnline(username)

    // Create JWT token
    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")

    const token = await new SignJWT({
      userId: user.id,
      username: user.username,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(secret)

    // Create response with user data (without password)
    const { passwordHash, ...userResponse } = user
    const response = NextResponse.json({
      message: "Login successful",
      user: userResponse,
    })

    // Set HTTP-only cookie
    response.cookies.set("auth-token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24, // 24 hours
    })

    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

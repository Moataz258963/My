import { type NextRequest, NextResponse } from "next/server"
import { jwtVerify } from "jose"
import { readFile } from "fs/promises"
import { existsSync } from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  fullName: string
  passwordHash: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")

async function getUsers(): Promise<User[]> {
  try {
    if (!existsSync(USERS_FILE)) {
      return []
    }
    const data = await readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")

    const { payload } = await jwtVerify(token, secret)
    const userId = payload.userId as string

    const users = await getUsers()
    const user = users.find((u) => u.id === userId)

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const { passwordHash, ...userResponse } = user
    return NextResponse.json({ user: userResponse })
  } catch (error) {
    return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  }
}

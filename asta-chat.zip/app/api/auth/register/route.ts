import { type NextRequest, NextResponse } from "next/server"
import { writeFile, readFile, mkdir } from "fs/promises"
import { existsSync } from "fs"
import path from "path"
import bcrypt from "bcryptjs"

interface User {
  id: string
  username: string
  email: string
  fullName: string
  passwordHash: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads")

async function ensureDirectories() {
  if (!existsSync(DATA_DIR)) {
    await mkdir(DATA_DIR, { recursive: true })
  }
  if (!existsSync(UPLOADS_DIR)) {
    await mkdir(UPLOADS_DIR, { recursive: true })
  }
}

async function getUsers(): Promise<User[]> {
  try {
    if (!existsSync(USERS_FILE)) {
      return []
    }
    const data = await readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function saveUsers(users: User[]) {
  await ensureDirectories()
  await writeFile(USERS_FILE, JSON.stringify(users, null, 2))
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function validatePassword(password: string): boolean {
  return password.length >= 6
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    const username = formData.get("username") as string
    const email = formData.get("email") as string
    const fullName = formData.get("fullName") as string
    const password = formData.get("password") as string
    const profilePicture = formData.get("profilePicture") as File | null

    // Validation
    if (!username || !email || !fullName || !password) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    if (!validateEmail(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    if (!validatePassword(password)) {
      return NextResponse.json({ error: "Password must be at least 6 characters long" }, { status: 400 })
    }

    // Check for existing users
    const users = await getUsers()

    if (users.find((user) => user.username === username)) {
      return NextResponse.json({ error: "Username already exists" }, { status: 409 })
    }

    if (users.find((user) => user.email === email)) {
      return NextResponse.json({ error: "Email already registered" }, { status: 409 })
    }

    // Handle profile picture upload
    let profilePicturePath = ""
    if (profilePicture && profilePicture.size > 0) {
      await ensureDirectories()

      const bytes = await profilePicture.arrayBuffer()
      const buffer = Buffer.from(bytes)

      const fileExtension = profilePicture.name.split(".").pop()
      const fileName = `${username}_${Date.now()}.${fileExtension}`
      const filePath = path.join(UPLOADS_DIR, fileName)

      await writeFile(filePath, buffer)
      profilePicturePath = `/uploads/${fileName}`
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 12)

    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      username,
      email,
      fullName,
      passwordHash,
      profilePicture: profilePicturePath,
      createdAt: new Date().toISOString(),
      lastOnline: new Date().toISOString(),
    }

    users.push(newUser)
    await saveUsers(users)

    // Return success (without password hash)
    const { passwordHash: _, ...userResponse } = newUser
    return NextResponse.json({
      message: "User registered successfully",
      user: userResponse,
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

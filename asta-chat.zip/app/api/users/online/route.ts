import { type NextRequest, NextResponse } from "next/server"
import { jwtVerify } from "jose"
import { readFile } from "fs/promises"
import { existsSync } from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  fullName: string
  passwordHash: string
  profilePicture?: string
  createdAt: string
  lastOnline: string
}

const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")

async function getUsers(): Promise<User[]> {
  try {
    if (!existsSync(USERS_FILE)) {
      return []
    }
    const data = await readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch {
    return []
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const secret = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")
    const { payload } = await jwtVerify(token, secret)
    const currentUserId = payload.userId as string

    const users = await getUsers()
    const now = new Date()

    // Filter out current user and return user info without password
    const otherUsers = users
      .filter((user) => user.id !== currentUserId)
      .map((user) => {
        const lastOnlineDate = new Date(user.lastOnline)
        const diffInMinutes = Math.floor((now.getTime() - lastOnlineDate.getTime()) / (1000 * 60))

        return {
          id: user.id,
          username: user.username,
          fullName: user.fullName,
          profilePicture: user.profilePicture,
          isOnline: diffInMinutes < 5, // Consider online if active within 5 minutes
          lastOnline: user.lastOnline,
        }
      })

    return NextResponse.json({ users: otherUsers })
  } catch (error) {
    console.error("Get online users error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

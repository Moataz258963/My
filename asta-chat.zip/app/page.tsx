"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { MessageCircle, Users, Globe } from "lucide-react"
import { RegisterForm } from "@/components/register-form"
import { LoginForm } from "@/components/login-form"
import { ChatInterface } from "@/components/chat-interface"
import { getCurrentUser, type User } from "@/lib/auth-utils"

export default function HomePage() {
  const [isArabic, setIsArabic] = useState(false)
  const [showLogin, setShowLogin] = useState(false)
  const [showRegister, setShowRegister] = useState(false)
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const toggleLanguage = () => setIsArabic(!isArabic)

  useEffect(() => {
    checkAuthStatus()
  }, [])

  const checkAuthStatus = async () => {
    try {
      const result = await getCurrentUser()
      if (result.user) {
        setUser(result.user)
      }
    } catch (error) {
      // User not authenticated, stay on homepage
    } finally {
      setIsLoading(false)
    }
  }

  const handleLoginSuccess = () => {
    setShowLogin(false)
    checkAuthStatus()
  }

  const handleLogout = () => {
    setUser(null)
  }

  const content = {
    en: {
      title: "ASTA CHAT",
      tagline: "Connect, Share, Engage – Your Conversations Matter",
      welcome: "Welcome to ASTA CHAT! Join the conversation, whether in Arabic or English.",
      loginBtn: "Login",
      registerBtn: "Sign Up",
      features: {
        realTime: "Real-time messaging",
        multiLang: "Arabic & English support",
        secure: "Secure conversations",
      },
    },
    ar: {
      title: "أستا شات",
      tagline: "تواصل، شارك، تفاعل – محادثاتك مهمة",
      welcome: "مرحباً بك في أستا شات! انضم إلى المحادثة، سواء بالعربية أو الإنجليزية.",
      loginBtn: "تسجيل الدخول",
      registerBtn: "إنشاء حساب",
      features: {
        realTime: "رسائل فورية",
        multiLang: "دعم العربية والإنجليزية",
        secure: "محادثات آمنة",
      },
    },
  }

  const t = content[isArabic ? "ar" : "en"]

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50 flex items-center justify-center">
        <div className="text-center">
          <MessageCircle className="w-12 h-12 text-emerald-600 animate-pulse mx-auto mb-4" />
          <p className="text-slate-600 font-sans">Loading...</p>
        </div>
      </div>
    )
  }

  // Show chat interface for authenticated users instead of welcome message
  if (user) {
    return <ChatInterface user={user} isArabic={isArabic} onToggleLanguage={toggleLanguage} onLogout={handleLogout} />
  }

  if (showRegister) {
    return (
      <RegisterForm
        isArabic={isArabic}
        onBack={() => setShowRegister(false)}
        onToggleLanguage={toggleLanguage}
        onSuccess={() => {
          setShowRegister(false)
          setShowLogin(true)
        }}
      />
    )
  }

  if (showLogin) {
    return (
      <LoginForm
        isArabic={isArabic}
        onBack={() => setShowLogin(false)}
        onToggleLanguage={toggleLanguage}
        onSuccess={handleLoginSuccess}
      />
    )
  }

  return (
    <div
      className={`min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50 ${isArabic ? "rtl" : "ltr"}`}
    >
      {/* Header */}
      <header className="flex items-center justify-between p-6">
        <div className="flex items-center space-x-2">
          <MessageCircle className="w-8 h-8 text-emerald-600" />
          <h1 className="text-2xl font-bold text-emerald-600 font-sans">{t.title}</h1>
        </div>
        <Button
          variant="outline"
          onClick={toggleLanguage}
          className="border-emerald-200 text-emerald-600 hover:bg-emerald-50 bg-transparent"
        >
          <Globe className="w-4 h-4 mr-2" />
          {isArabic ? "English" : "العربية"}
        </Button>
      </header>

      {/* Main Content */}
      <main className="flex flex-col items-center justify-center px-6 py-12">
        <div className="text-center space-y-8 max-w-4xl">
          {/* Hero Section */}
          <div className="space-y-6">
            <h2 className="text-4xl md:text-6xl font-bold text-slate-800 font-sans leading-tight">{t.tagline}</h2>
            <p className="text-xl text-slate-600 font-sans leading-relaxed max-w-2xl mx-auto">{t.welcome}</p>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 my-12">
            <div className="flex flex-col items-center space-y-3 p-6 bg-white/60 rounded-xl backdrop-blur-sm">
              <MessageCircle className="w-12 h-12 text-emerald-600" />
              <h3 className="font-semibold text-slate-800 font-sans">{t.features.realTime}</h3>
            </div>
            <div className="flex flex-col items-center space-y-3 p-6 bg-white/60 rounded-xl backdrop-blur-sm">
              <Globe className="w-12 h-12 text-emerald-600" />
              <h3 className="font-semibold text-slate-800 font-sans">{t.features.multiLang}</h3>
            </div>
            <div className="flex flex-col items-center space-y-3 p-6 bg-white/60 rounded-xl backdrop-blur-sm">
              <Users className="w-12 h-12 text-emerald-600" />
              <h3 className="font-semibold text-slate-800 font-sans">{t.features.secure}</h3>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => setShowLogin(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 text-lg font-sans transition-all duration-200 hover:scale-105 shadow-lg"
            >
              {t.loginBtn}
            </Button>
            <Button
              onClick={() => setShowRegister(true)}
              variant="outline"
              className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 px-8 py-3 text-lg font-sans transition-all duration-200 hover:scale-105"
            >
              {t.registerBtn}
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { X, Camera, Loader2, CheckCircle, AlertCircle, Eye, EyeOff } from "lucide-react"
import { updateProfile, uploadProfilePicture, validateProfileForm, type UpdateProfileData } from "@/lib/profile-utils"
import type { User } from "@/lib/auth-utils"

interface ProfileSettingsProps {
  user: User
  isArabic: boolean
  onClose: () => void
  onUserUpdate: (updatedUser: User) => void
}

export function ProfileSettings({ user, isArabic, onClose, onUserUpdate }: ProfileSettingsProps) {
  const [formData, setFormData] = useState<UpdateProfileData>({
    fullName: user.fullName,
    email: user.email,
    currentPassword: "",
    newPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isUploadingPicture, setIsUploadingPicture] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)

  const content = {
    en: {
      title: "Profile Settings",
      subtitle: "Manage your account information and preferences",
      profilePicture: "Profile Picture",
      changePicture: "Change Picture",
      personalInfo: "Personal Information",
      fullName: "Full Name",
      email: "Email Address",
      username: "Username",
      security: "Security",
      currentPassword: "Current Password",
      newPassword: "New Password (Optional)",
      changePassword: "Leave blank to keep current password",
      save: "Save Changes",
      cancel: "Cancel",
      saving: "Saving...",
      uploading: "Uploading...",
      success: "Profile updated successfully!",
      pictureSuccess: "Profile picture updated successfully!",
    },
    ar: {
      title: "إعدادات الملف الشخصي",
      subtitle: "إدارة معلومات حسابك وتفضيلاتك",
      profilePicture: "الصورة الشخصية",
      changePicture: "تغيير الصورة",
      personalInfo: "المعلومات الشخصية",
      fullName: "الاسم الكامل",
      email: "عنوان البريد الإلكتروني",
      username: "اسم المستخدم",
      security: "الأمان",
      currentPassword: "كلمة المرور الحالية",
      newPassword: "كلمة المرور الجديدة (اختياري)",
      changePassword: "اتركه فارغاً للاحتفاظ بكلمة المرور الحالية",
      save: "حفظ التغييرات",
      cancel: "إلغاء",
      saving: "جاري الحفظ...",
      uploading: "جاري الرفع...",
      success: "تم تحديث الملف الشخصي بنجاح!",
      pictureSuccess: "تم تحديث الصورة الشخصية بنجاح!",
    },
  }

  const t = content[isArabic ? "ar" : "en"]

  const handleInputChange = (field: keyof UpdateProfileData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setError("")
    setSuccess("")
  }

  const handleProfilePictureChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploadingPicture(true)
    setError("")
    setSuccess("")

    try {
      const result = await uploadProfilePicture(file)

      if (result.error) {
        setError(result.error)
      } else {
        setSuccess(t.pictureSuccess)
        onUserUpdate(result.user)
        setTimeout(() => setSuccess(""), 3000)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsUploadingPicture(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    // Client-side validation
    const validationError = validateProfileForm(formData)
    if (validationError) {
      setError(validationError)
      return
    }

    setIsLoading(true)

    try {
      const result = await updateProfile(formData)

      if (result.error) {
        setError(result.error)
      } else {
        setSuccess(t.success)
        onUserUpdate(result.user)
        // Clear password fields
        setFormData((prev) => ({ ...prev, currentPassword: "", newPassword: "" }))
        setTimeout(() => setSuccess(""), 3000)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className={`w-full max-w-2xl max-h-[90vh] overflow-y-auto ${isArabic ? "rtl" : "ltr"}`}>
        <Card className="shadow-2xl border-0 bg-white">
          <CardHeader className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-700"
              disabled={isLoading || isUploadingPicture}
            >
              <X className="w-4 h-4" />
            </Button>
            <CardTitle className="text-2xl font-bold text-slate-800 font-sans">{t.title}</CardTitle>
            <CardDescription className="text-slate-600 font-sans">{t.subtitle}</CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Profile Picture Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-800 font-sans">{t.profilePicture}</h3>
              <div className="flex items-center space-x-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={user.profilePicture || "/placeholder.svg"} />
                  <AvatarFallback className="bg-emerald-600 text-white text-xl">
                    {user.fullName.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <Label htmlFor="profile-picture" className="cursor-pointer">
                    <div className="flex items-center space-x-2 text-emerald-600 hover:text-emerald-700">
                      {isUploadingPicture ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span className="font-sans">{t.uploading}</span>
                        </>
                      ) : (
                        <>
                          <Camera className="w-4 h-4" />
                          <span className="font-sans">{t.changePicture}</span>
                        </>
                      )}
                    </div>
                  </Label>
                  <Input
                    id="profile-picture"
                    type="file"
                    accept="image/*"
                    onChange={handleProfilePictureChange}
                    className="hidden"
                    disabled={isUploadingPicture || isLoading}
                  />
                </div>
              </div>
            </div>

            <Separator />

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-800 font-sans">{t.personalInfo}</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName" className="font-sans">
                      {t.fullName}
                    </Label>
                    <Input
                      id="fullName"
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange("fullName", e.target.value)}
                      className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                      disabled={isLoading}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="font-sans">
                      {t.email}
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                      disabled={isLoading}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="username" className="font-sans">
                    {t.username}
                  </Label>
                  <Input
                    id="username"
                    type="text"
                    value={user.username}
                    className="border-slate-200 bg-slate-50 text-slate-500"
                    disabled
                    readOnly
                  />
                  <p className="text-sm text-slate-500 font-sans">Username cannot be changed</p>
                </div>
              </div>

              <Separator />

              {/* Security Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-800 font-sans">{t.security}</h3>
                <p className="text-sm text-slate-600 font-sans">{t.changePassword}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword" className="font-sans">
                      {t.currentPassword}
                    </Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        type={showCurrentPassword ? "text" : "password"}
                        value={formData.currentPassword}
                        onChange={(e) => handleInputChange("currentPassword", e.target.value)}
                        className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500 pr-10"
                        disabled={isLoading}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 text-slate-500 hover:text-slate-700"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        disabled={isLoading}
                      >
                        {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="newPassword" className="font-sans">
                      {t.newPassword}
                    </Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showNewPassword ? "text" : "password"}
                        value={formData.newPassword}
                        onChange={(e) => handleInputChange("newPassword", e.target.value)}
                        className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500 pr-10"
                        disabled={isLoading}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 text-slate-500 hover:text-slate-700"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        disabled={isLoading}
                      >
                        {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Error/Success Messages */}
              {error && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-sans">{error}</span>
                </div>
              )}

              {success && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50 p-3 rounded-lg">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-sans">{success}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex justify-end space-x-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isLoading || isUploadingPicture}
                  className="font-sans bg-transparent"
                >
                  {t.cancel}
                </Button>
                <Button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans"
                  disabled={isLoading || isUploadingPicture}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      {t.saving}
                    </>
                  ) : (
                    t.save
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

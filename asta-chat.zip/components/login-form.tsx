"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Globe, Loader2, AlertCircle } from "lucide-react"
import { loginUser, validateLoginForm, type LoginFormData } from "@/lib/auth-utils"

interface LoginFormProps {
  isArabic: boolean
  onBack: () => void
  onToggleLanguage: () => void
  onSuccess: () => void
}

export function LoginForm({ isArabic, onBack, onToggleLanguage, onSuccess }: LoginFormProps) {
  const [formData, setFormData] = useState<LoginFormData>({
    username: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const content = {
    en: {
      title: "ASTA CHAT",
      login: "Log in to your account",
      loginBtn: "Login",
      backToHome: "Back to Home",
      username: "Username",
      password: "Password",
      forgotPassword: "Forgot your password?",
      loggingIn: "Logging in...",
    },
    ar: {
      title: "أستا شات",
      login: "تسجيل الدخول إلى حسابك",
      loginBtn: "تسجيل الدخول",
      backToHome: "العودة للرئيسية",
      username: "اسم المستخدم",
      password: "كلمة المرور",
      forgotPassword: "نسيت كلمة المرور؟",
      loggingIn: "جاري تسجيل الدخول...",
    },
  }

  const t = content[isArabic ? "ar" : "en"]

  const handleInputChange = (field: keyof LoginFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Client-side validation
    const validationError = validateLoginForm(formData)
    if (validationError) {
      setError(validationError)
      return
    }

    setIsLoading(true)

    try {
      const result = await loginUser(formData)

      if (result.error) {
        setError(result.error)
      } else {
        onSuccess()
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div
      className={`min-h-screen bg-gradient-to-br from-emerald-50 to-white flex items-center justify-center p-4 ${isArabic ? "rtl" : "ltr"}`}
    >
      <div className="w-full max-w-md">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center space-y-4">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={onBack}
                className="text-emerald-600 hover:text-emerald-700"
                disabled={isLoading}
              >
                {t.backToHome}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onToggleLanguage}
                className="border-emerald-200 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                disabled={isLoading}
              >
                <Globe className="w-4 h-4 mr-1" />
                {isArabic ? "EN" : "عر"}
              </Button>
            </div>
            <CardTitle className="text-2xl font-bold text-emerald-600 font-sans">{t.title}</CardTitle>
            <CardDescription className="text-slate-600 font-sans">{t.login}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="font-sans">
                  {t.username}
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={formData.username}
                  onChange={(e) => handleInputChange("username", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="font-sans">
                  {t.password}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              {error && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-sans">{error}</span>
                </div>
              )}

              <Button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans transition-all duration-200 hover:scale-105"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {t.loggingIn}
                  </>
                ) : (
                  t.loginBtn
                )}
              </Button>

              <div className="text-center">
                <Button
                  variant="link"
                  className="text-emerald-600 hover:text-emerald-700 font-sans"
                  disabled={isLoading}
                  type="button"
                >
                  {t.forgotPassword}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

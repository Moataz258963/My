"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, Send, LogOut, Globe, Settings, Users, MoreVertical } from "lucide-react"
import { logoutUser, type User } from "@/lib/auth-utils"
import {
  sendMessage,
  getMessages,
  getOnlineUsers,
  getChatId,
  formatTime,
  formatLastSeen,
  type ChatMessage,
  type ChatUser,
} from "@/lib/chat-utils"
import { ProfileSettings } from "./profile-settings"

interface ChatInterfaceProps {
  user: User
  isArabic: boolean
  onToggleLanguage: () => void
  onLogout: () => void
}

export function ChatInterface({ user, isArabic, onToggleLanguage, onLogout }: ChatInterfaceProps) {
  const [message, setMessage] = useState("")
  const [selectedUser, setSelectedUser] = useState<ChatUser | null>(null)
  const [onlineUsers, setOnlineUsers] = useState<ChatUser[]>([])
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [currentUser, setCurrentUser] = useState<User>(user)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const pollingRef = useRef<NodeJS.Timeout | null>(null)

  const content = {
    en: {
      title: "ASTA CHAT",
      onlineUsers: "Online Users",
      typeMessage: "Type a message...",
      send: "Send",
      logout: "Logout",
      settings: "Settings",
      noUserSelected: "Select a user to start chatting",
      noMessages: "No messages yet. Start the conversation!",
      you: "You",
      online: "Online",
      offline: "Offline",
      lastSeen: "Last seen",
      sending: "Sending...",
    },
    ar: {
      title: "أستا شات",
      onlineUsers: "المستخدمون المتصلون",
      typeMessage: "اكتب رسالة...",
      send: "إرسال",
      logout: "تسجيل الخروج",
      settings: "الإعدادات",
      noUserSelected: "اختر مستخدماً لبدء المحادثة",
      noMessages: "لا توجد رسائل بعد. ابدأ المحادثة!",
      you: "أنت",
      online: "متصل",
      offline: "غير متصل",
      lastSeen: "آخر ظهور",
      sending: "جاري الإرسال...",
    },
  }

  const t = content[isArabic ? "ar" : "en"]

  useEffect(() => {
    loadOnlineUsers()

    // Set up polling for online users every 30 seconds
    const interval = setInterval(loadOnlineUsers, 30000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (selectedUser) {
      loadMessages()

      // Set up polling for new messages every 3 seconds
      pollingRef.current = setInterval(loadMessages, 3000)
    } else {
      // Clear polling when no user is selected
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
        pollingRef.current = null
      }
    }

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
        pollingRef.current = null
      }
    }
  }, [selectedUser])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const loadOnlineUsers = async () => {
    try {
      const result = await getOnlineUsers()
      if (result.users) {
        setOnlineUsers(result.users)
      }
    } catch (error) {
      console.error("Error loading users:", error)
    }
  }

  const loadMessages = async () => {
    if (!selectedUser) return

    try {
      const chatId = getChatId(currentUser.id, selectedUser.id)
      const result = await getMessages(chatId)
      if (result.messages) {
        setMessages(result.messages)
      }
    } catch (error) {
      console.error("Error loading messages:", error)
    }
  }

  const handleLogout = async () => {
    setIsLoading(true)
    try {
      await logoutUser()
      onLogout()
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedUser || isSending) return

    const messageContent = message.trim()
    setMessage("")
    setIsSending(true)

    try {
      const result = await sendMessage(selectedUser.id, messageContent)

      if (result.error) {
        console.error("Send message error:", result.error)
        // Restore message on error
        setMessage(messageContent)
      } else {
        // Immediately add the message to local state for instant feedback
        const newMessage: ChatMessage = {
          id: Date.now().toString(),
          senderId: currentUser.id,
          senderName: currentUser.fullName,
          receiverId: selectedUser.id,
          content: messageContent,
          timestamp: new Date().toISOString(),
          isRead: false,
        }
        setMessages((prev) => [...prev, newMessage])

        // Reload messages to get the server version
        setTimeout(loadMessages, 500)
      }
    } catch (error) {
      console.error("Send message error:", error)
      setMessage(messageContent)
    } finally {
      setIsSending(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleUserSelect = (chatUser: ChatUser) => {
    setSelectedUser(chatUser)
    setMessages([]) // Clear messages when switching users
  }

  const handleUserUpdate = (updatedUser: User) => {
    setCurrentUser(updatedUser)
  }

  return (
    <>
      <div className={`h-screen bg-gradient-to-br from-emerald-50 to-white flex ${isArabic ? "rtl" : "ltr"}`}>
        {/* Sidebar */}
        <div className="w-80 bg-white/80 backdrop-blur-sm border-r border-emerald-100 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-emerald-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <MessageCircle className="w-6 h-6 text-emerald-600" />
                <h1 className="text-xl font-bold text-emerald-600 font-sans">{t.title}</h1>
              </div>
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onToggleLanguage}
                  className="text-emerald-600 hover:bg-emerald-50"
                >
                  <Globe className="w-4 h-4" />
                </Button>
                {/* Added settings button functionality */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSettings(true)}
                  className="text-emerald-600 hover:bg-emerald-50"
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Current User */}
            <div className="flex items-center space-x-3 p-3 bg-emerald-50 rounded-lg">
              <Avatar className="w-10 h-10">
                <AvatarImage src={currentUser.profilePicture || "/placeholder.svg"} />
                <AvatarFallback className="bg-emerald-600 text-white">
                  {currentUser.fullName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-800 font-sans truncate">{currentUser.fullName}</p>
                <p className="text-sm text-emerald-600 font-sans">@{currentUser.username}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                disabled={isLoading}
                className="text-slate-500 hover:text-red-600 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Online Users */}
          <div className="flex-1 flex flex-col">
            <div className="p-4 pb-2">
              <div className="flex items-center space-x-2 mb-3">
                <Users className="w-4 h-4 text-slate-600" />
                <h2 className="font-semibold text-slate-800 font-sans">{t.onlineUsers}</h2>
                <span className="text-sm text-slate-500 bg-slate-100 px-2 py-1 rounded-full">
                  {onlineUsers.filter((u) => u.isOnline).length}
                </span>
              </div>
            </div>

            <ScrollArea className="flex-1 px-4">
              <div className="space-y-2">
                {onlineUsers.map((chatUser) => (
                  <Card
                    key={chatUser.id}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                      selectedUser?.id === chatUser.id
                        ? "bg-emerald-50 border-emerald-200"
                        : "bg-white/60 hover:bg-white/80"
                    }`}
                    onClick={() => handleUserSelect(chatUser)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={chatUser.profilePicture || "/placeholder.svg"} />
                            <AvatarFallback className="bg-slate-400 text-white">
                              {chatUser.fullName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div
                            className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                              chatUser.isOnline ? "bg-green-500" : "bg-slate-400"
                            }`}
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-slate-800 font-sans truncate">{chatUser.fullName}</p>
                          <p className="text-sm text-slate-500 font-sans truncate">
                            {formatLastSeen(chatUser.lastOnline, isArabic)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedUser ? (
            <>
              {/* Chat Header */}
              <div className="p-4 bg-white/80 backdrop-blur-sm border-b border-emerald-100">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={selectedUser.profilePicture || "/placeholder.svg"} />
                      <AvatarFallback className="bg-slate-400 text-white">
                        {selectedUser.fullName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-slate-800 font-sans">{selectedUser.fullName}</h3>
                      <p className="text-sm text-slate-500 font-sans">
                        {formatLastSeen(selectedUser.lastOnline, isArabic)}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="text-slate-500 hover:bg-slate-100">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Messages Area */}
              <ScrollArea className="flex-1 p-4">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center space-y-3">
                      <MessageCircle className="w-12 h-12 text-slate-300 mx-auto" />
                      <p className="text-slate-500 font-sans">{t.noMessages}</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.senderId === currentUser.id ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                            msg.senderId === currentUser.id
                              ? "bg-emerald-600 text-white"
                              : "bg-white border border-slate-200"
                          }`}
                        >
                          <p className="font-sans">{msg.content}</p>
                          <p
                            className={`text-xs mt-1 ${
                              msg.senderId === currentUser.id ? "text-emerald-100" : "text-slate-500"
                            }`}
                          >
                            {formatTime(msg.timestamp, isArabic)}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 bg-white/80 backdrop-blur-sm border-t border-emerald-100">
                <div className="flex items-center space-x-2">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={t.typeMessage}
                    className="flex-1 border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                    disabled={isSending}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!message.trim() || isSending}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-4"
                  >
                    {isSending ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            </>
          ) : (
            /* No User Selected */
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center space-y-4">
                <MessageCircle className="w-16 h-16 text-slate-300 mx-auto" />
                <h3 className="text-xl font-semibold text-slate-600 font-sans">{t.noUserSelected}</h3>
                <p className="text-slate-500 font-sans">Choose someone from the sidebar to start chatting</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Profile Settings Modal */}
      {showSettings && (
        <ProfileSettings
          user={currentUser}
          isArabic={isArabic}
          onClose={() => setShowSettings(false)}
          onUserUpdate={handleUserUpdate}
        />
      )}
    </>
  )
}

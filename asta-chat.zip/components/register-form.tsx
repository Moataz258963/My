"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Globe, Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { registerUser, validateForm, type RegisterFormData } from "@/lib/auth-utils"

interface RegisterFormProps {
  isArabic: boolean
  onBack: () => void
  onToggleLanguage: () => void
  onSuccess: () => void
}

export function RegisterForm({ isArabic, onBack, onToggleLanguage, onSuccess }: RegisterFormProps) {
  const [formData, setFormData] = useState<RegisterFormData>({
    username: "",
    email: "",
    fullName: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const content = {
    en: {
      title: "ASTA CHAT",
      register: "Create a new account",
      registerBtn: "Sign Up",
      backToHome: "Back to Home",
      username: "Username",
      password: "Password",
      email: "Email",
      fullName: "Full Name",
      profilePicture: "Profile Picture (Optional)",
      creating: "Creating Account...",
      success: "Account created successfully!",
    },
    ar: {
      title: "أستا شات",
      register: "إنشاء حساب جديد",
      registerBtn: "إنشاء حساب",
      backToHome: "العودة للرئيسية",
      username: "اسم المستخدم",
      password: "كلمة المرور",
      email: "البريد الإلكتروني",
      fullName: "الاسم الكامل",
      profilePicture: "الصورة الشخصية (اختياري)",
      creating: "جاري إنشاء الحساب...",
      success: "تم إنشاء الحساب بنجاح!",
    },
  }

  const t = content[isArabic ? "ar" : "en"]

  const handleInputChange = (field: keyof RegisterFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setError("")
  }

  const handleFileChange = (file: File | null) => {
    setFormData((prev) => ({ ...prev, profilePicture: file || undefined }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    // Client-side validation
    const validationError = validateForm(formData)
    if (validationError) {
      setError(validationError)
      return
    }

    setIsLoading(true)

    try {
      const result = await registerUser(formData)

      if (result.error) {
        setError(result.error)
      } else {
        setSuccess(t.success)
        setTimeout(() => {
          onSuccess()
        }, 2000)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div
      className={`min-h-screen bg-gradient-to-br from-emerald-50 to-white flex items-center justify-center p-4 ${isArabic ? "rtl" : "ltr"}`}
    >
      <div className="w-full max-w-md">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center space-y-4">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={onBack}
                className="text-emerald-600 hover:text-emerald-700"
                disabled={isLoading}
              >
                {t.backToHome}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onToggleLanguage}
                className="border-emerald-200 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                disabled={isLoading}
              >
                <Globe className="w-4 h-4 mr-1" />
                {isArabic ? "EN" : "عر"}
              </Button>
            </div>
            <CardTitle className="text-2xl font-bold text-emerald-600 font-sans">{t.title}</CardTitle>
            <CardDescription className="text-slate-600 font-sans">{t.register}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullname" className="font-sans">
                  {t.fullName}
                </Label>
                <Input
                  id="fullname"
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange("fullName", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-username" className="font-sans">
                  {t.username}
                </Label>
                <Input
                  id="reg-username"
                  type="text"
                  value={formData.username}
                  onChange={(e) => handleInputChange("username", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-email" className="font-sans">
                  {t.email}
                </Label>
                <Input
                  id="reg-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-password" className="font-sans">
                  {t.password}
                </Label>
                <Input
                  id="reg-password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="profile-pic" className="font-sans">
                  {t.profilePicture}
                </Label>
                <Input
                  id="profile-pic"
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
                  className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  disabled={isLoading}
                />
              </div>

              {error && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-sans">{error}</span>
                </div>
              )}

              {success && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50 p-3 rounded-lg">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-sans">{success}</span>
                </div>
              )}

              <Button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans transition-all duration-200 hover:scale-105"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {t.creating}
                  </>
                ) : (
                  t.registerBtn
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
